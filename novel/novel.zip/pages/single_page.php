 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
     <!-- Content Header (Page header) -->
     <div class="content-header" style="background-image: url(../ampunnya/dist/img/gambar2.jpg) ;">

     </div>
     <!-- /.content-header -->

     <!-- Main content -->
     <div class="content page p-3">
         <div class="container">
             <div class="row">
                 <div class="col-lg-8">
                     <div class="card">
                         <div class="card-header">
                             <h1>Judul Post</h1>
                             <h4 class="color-grey">Judul Novel</h4>
                         </div>
                         <div class="card-body text-justify">
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis dicta labore molestias
                                 distinctio dolorum. Eligendi commodi veniam vero magnam adipisci pariatur tempora a
                                 culpa incidunt maxime exercitationem, voluptate itaque et esse nisi mollitia! Veritatis
                                 fugiat doloribus accusamus officiis nostrum optio earum adipisci aperiam quae
                                 accusantium iusto, impedit nemo dicta dolores.</p>
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis dicta labore molestias
                                 distinctio dolorum. Eligendi commodi veniam vero magnam adipisci pariatur tempora a
                                 culpa incidunt maxime exercitationem, voluptate itaque et esse nisi mollitia! Veritatis
                                 fugiat doloribus accusamus officiis nostrum optio earum adipisci aperiam quae
                                 accusantium iusto, impedit nemo dicta dolores.</p>
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis dicta labore molestias
                                 distinctio dolorum. Eligendi commodi veniam vero magnam adipisci pariatur tempora a
                                 culpa incidunt maxime exercitationem, voluptate itaque et esse nisi mollitia! Veritatis
                                 fugiat doloribus accusamus officiis nostrum optio earum adipisci aperiam quae
                                 accusantium iusto, impedit nemo dicta dolores.</p>
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis dicta labore molestias
                                 distinctio dolorum. Eligendi commodi veniam vero magnam adipisci pariatur tempora a
                                 culpa incidunt maxime exercitationem, voluptate itaque et esse nisi mollitia! Veritatis
                                 fugiat doloribus accusamus officiis nostrum optio earum adipisci aperiam quae
                                 accusantium iusto, impedit nemo dicta dolores.</p>

                         </div>
                     </div>
                     <div class="row">
                         <div class="col-4 text-center pb-5">
                             <a href="#" class="btn btn-info">Prev</a>
                         </div>
                         <div class="col-4 text-center pb-5">
                             <a href="#" class="btn btn-info">Toc</a>
                         </div>
                         <div class="col-4 text-center pb-5">
                             <a href="#" class="btn btn-info">Next</a>
                         </div>
                     </div>
                 </div>
                 <!-- /.col-md-6 -->
                 <div class="col-lg-4">
                     <?php include "pages/side_bar.php"; ?>
                 </div>
                 <!-- /.col-md-6 -->
             </div>
             <!-- /.row -->
         </div><!-- /.container-fluid -->
     </div>
     <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->