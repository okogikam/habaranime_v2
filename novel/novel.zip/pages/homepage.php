 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
     <!-- Main content -->
     <div class="content pt-3">
         <div class="container">
             <h2>New Post</h2>
             <div class="row">
                 <div class="col-lg-8">
                     <a href="?s=post&id=1">
                         <div class="card">
                             <div class="card-img" style="background-image:url(../ampunnya/dist/img/gambar1.jpg);">
                                 <!-- <img class="img-cover" src="../ampunnya/dist/img/gambar1.jpg" alt=""> -->
                             </div>
                             <div class="card-body">
                                 <h5 class="card-title">Card title</h5>
                                 <p class="card-text">
                                     Some quick example text to build on the card title and make up the bulk of the
                                     card's
                                     content.
                                 </p>
                             </div>
                         </div>
                     </a>
                     <a href="?s=post&id=2">
                         <div class="card">
                             <div class="card-img" style="background-image:url(../ampunnya/dist/img/gambar1.jpg);">
                                 <!-- <img class="img-cover" src="../ampunnya/dist/img/gambar1.jpg" alt=""> -->
                             </div>
                             <div class="card-body">
                                 <h5 class="card-title">Card title</h5>
                                 <p class="card-text">
                                     Some quick example text to build on the card title and make up the bulk of the
                                     card's
                                     content.
                                 </p>
                             </div>
                         </div>
                     </a>
                 </div>
                 <!-- /.col-md-6 -->
                 <div class="col-lg-4">
                     <?php include "pages/side_bar.php"; ?>
                 </div>
                 <!-- /.col-md-6 -->
             </div>
             <!-- /.row -->
         </div><!-- /.container-fluid -->
     </div>
     <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->