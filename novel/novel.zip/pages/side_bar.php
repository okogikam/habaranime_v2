<div class="card">
    <div class="card-header">
        <h5 class="card-title m-0">Project</h5>
    </div>
    <div class="card-body">
        <table class="table table-bover">
            <thead>
                <tr>
                    <th>Series</th>
                    <th class="text-right">Ch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><a href="?s=page&id=1">Novel 1</a></td>
                    <td class="text-right">34ch</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>