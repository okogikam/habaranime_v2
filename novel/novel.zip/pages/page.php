 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
     <!-- Content Header (Page header) -->
     <div class="content-header" style="background-image: url(../ampunnya/dist/img/gambar2.jpg) ;">

     </div>
     <!-- /.content-header -->

     <!-- Main content -->
     <div class="content page">
         <div class="container">
             <div class="row">
                 <div class="col-lg-8">
                     <div class="card">
                         <div class="card-body">
                             <div class="row">
                                 <div class="col-sm-5 cover-img">
                                     <div class="card-img">
                                         <img src="../ampunnya/dist/img/gambar2.jpg" alt="" sizes="" srcset="">
                                     </div>
                                 </div>
                                 <div class="col-sm-7 ringkasan">
                                     <h5 class="card-title">Card title</h5>

                                     <p class="card-text">
                                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi, atque deleniti!
                                         Expedita id numquam possimus, animi odit enim, soluta sit explicabo ullam nobis
                                         culpa
                                         vero optio, doloremque magni placeat qui unde accusamus pariatur? Corporis
                                         cumque
                                         recusandae impedit esse, accusantium eius illum natus, placeat quae eos, dolor
                                         vel
                                         commodi hic qui?
                                     </p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="card">
                         <div class="card-header">
                             <h4>Series List</h4>
                         </div>
                         <div class="card-body">
                             <ul class="nav">
                                 <li class="nav-item">
                                     <a class="nav-link" href="?s=post&id=1">Lorem ipsum dolor sit amet
                                         consectetur adipisicing
                                         elit. Temporibus,
                                         hic!</a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" href="#">Lorem ipsum dolor sit amet
                                         consectetur adipisicing
                                         elit. Temporibus,
                                         hic!</a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" href="#">Lorem ipsum dolor sit amet
                                         consectetur adipisicing
                                         elit. Temporibus,
                                         hic!</a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" href="#">Lorem ipsum dolor sit amet
                                         consectetur adipisicing
                                         elit. Temporibus,
                                         hic!</a>
                                 </li>

                             </ul>
                         </div>
                     </div>
                 </div>
                 <!-- /.col-md-6 -->
                 <div class="col-lg-4">
                     <?php include "pages/side_bar.php"; ?>
                 </div>
                 <!-- /.col-md-6 -->
             </div>
             <!-- /.row -->
         </div><!-- /.container-fluid -->
     </div>
     <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->